./mf2k-mst-cpcc09dpl.x P2Rv9.1.nam
cd mod2tec
./many2tim_d.x < many2tim_d.in
cd ..

